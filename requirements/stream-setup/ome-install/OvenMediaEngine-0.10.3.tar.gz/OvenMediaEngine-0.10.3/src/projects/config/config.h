#pragma once

#include "items/items.h"
#include "config_manager.h"