//==============================================================================
//
//  OvenMediaEngine
//
//  Created by Gil Hoon Choi
//  Copyright (c) 2018 AirenSoft. All rights reserved.
//
//==============================================================================
#pragma once

class ConfigMacroConverter
{
public:
    ConfigMacroConverter();
    virtual ~ConfigMacroConverter();
};
