//==============================================================================
//
//  Provider Base Class 
//
//  Created by Kwon Keuk Han
//  Copyright (c) 2018 AirenSoft. All rights reserved.
//
//==============================================================================


#include "stream.h"
#include "application.h"
#include "base/info/application.h"
#include "provider_private.h"

namespace pvd
{
	Stream::Stream(const std::shared_ptr<pvd::Application> &application, StreamSourceType source_type)
		:info::Stream(*(std::static_pointer_cast<info::Application>(application)), source_type),
		_application(application)
	{
	}

	Stream::Stream(const std::shared_ptr<pvd::Application> &application, info::stream_id_t stream_id, StreamSourceType source_type)
		:info::Stream((*std::static_pointer_cast<info::Application>(application)), stream_id, source_type),
		_application(application)
	{
	}

	Stream::Stream(const std::shared_ptr<pvd::Application> &application, const info::Stream &stream_info)
		:info::Stream(stream_info),
		_application(application)
	{
	}

	Stream::~Stream()
	{

	}

	bool Stream::Start() 
	{
		logti("%s has started [%s(%u)] stream", _application->GetApplicationTypeName(), GetName().CStr(), GetId());
		return true;
	}

	bool Stream::Play()
	{
		logti("%s has started to play [%s(%u)] stream", _application->GetApplicationTypeName(), GetName().CStr(), GetId());
		return true;
	}
	
	bool Stream::Stop() 
	{
		logti("%s has stopped playing [%s(%u)] stream", _application->GetApplicationTypeName(), GetName().CStr(), GetId());
		return true;
	}
}