#pragma once

// Common defines and stuff for the whole RTSP library

// Enables H264 bitstream analysis in the RtpTrack class
//#define PARANOID_STREAM_VALIDATION