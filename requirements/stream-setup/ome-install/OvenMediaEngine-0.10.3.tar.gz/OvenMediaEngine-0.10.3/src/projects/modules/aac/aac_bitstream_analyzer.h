#pragma once

#include <base/ovlibrary/ovlibrary.h>

class AACBitstreamAnalyzer
{
public:
	static bool IsValidAdtsUnit(const uint8_t *payload);

private:

};