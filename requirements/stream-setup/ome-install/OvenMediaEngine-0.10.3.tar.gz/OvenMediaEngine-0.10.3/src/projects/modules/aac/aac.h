#pragma once

#include <base/ovlibrary/ovlibrary.h>

#include "aac_bitstream_analyzer.h"
#include "aac_adts.h"
