//==============================================================================
//
//  OvenMediaEngine
//
//  Created by Hyunjun Jang
//  Copyright (c) 2018 AirenSoft. All rights reserved.
//
//==============================================================================
#pragma once

#include "http_server/interceptors/default/http_default_interceptor.h"
#include "web_socket/web_socket_interceptor.h"
